stress --cpu  8 --timeout 30 > /dev/null 2>&1
